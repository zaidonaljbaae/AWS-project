def msg_(message): return message

SUCCESS = msg_('Request success')
CREATED = msg_('Created')
NO_CONTENT = msg_('No content')
INVALID_INPUT = msg_('Invalid input')
BAD_REQUEST = msg_('Bad request')
UNAUTHORIZED = msg_('Unauthorized')
NOT_FOUND = msg_('Not found')
