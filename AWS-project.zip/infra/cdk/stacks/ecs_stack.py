from __future__ import annotations

import os
from pathlib import Path

from aws_cdk import (
    Stack,
    Duration,
    aws_ec2 as ec2,
    aws_ecs as ecs,
    aws_ecs_patterns as ecs_patterns,
    aws_logs as logs,
)
from constructs import Construct


class TemplateEcsStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # ====== Networking ======
        # IMPORTANT: An ALB can only attach Security Groups from the SAME VPC.
        # If you previously deployed this stack using a different VPC and later changed the lookup,
        # CloudFormation can fail with:
        #   "One or more security groups are invalid"
        #
        # Pro rule: make the VPC choice explicit and stable across deployments.
        #
        # Options:
        # 1) Provide an existing VPC id via env var VPC_ID (recommended in shared AWS accounts)
        # 2) If VPC_ID is not set, CDK will CREATE a dedicated VPC (recommended for demos/sandboxes)
        vpc_id = os.getenv("VPC_ID") or os.getenv("VPCID")
        if not vpc_id:
            raise ValueError(
                "VPC_ID is required (or VPCID). "
                "Set it to an existing VPC id, e.g. vpc-xxxxxxxx."
            )

        # Accept SUBNET_IDS as: "subnet-a,subnet-b" OR "subnet-a subnet-b"
        subnet_ids_env = os.getenv("SUBNET_IDS") or os.getenv("SUBNETIDS") or ""
        subnet_ids = [s.strip() for s in re.split(r"[,\s]+", subnet_ids_env) if s.strip()]

        vpc = ec2.Vpc.from_lookup(self, "ImportedVPC", vpc_id=vpc_id)

        # If explicit subnet IDs are provided, force tasks into those subnets.
        # Otherwise, default to private subnets in the VPC.
        if subnet_ids:
            subnets = [
                ec2.Subnet.from_subnet_id(self, f"Subnet{i}", subnet_id=sid)
                for i, sid in enumerate(subnet_ids)
            ]
            subnet_selection = ec2.SubnetSelection(subnets=subnets)
        else:
            subnet_selection = ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS)

        cluster = ecs.Cluster(self, "Cluster", vpc=vpc)

        # ====== Task Definition ======
        task_def = ecs.FargateTaskDefinition(
            self,
            "TaskDef",
            cpu=512,
            memory_limit_mib=1024,
        )

        # ====== Docker context directory (IMPORTANT!) ======
        # Put ONLY the ECS service folder here, NOT the project root.
        # Expected: src/app/ecs_service/Dockerfile
        repo_root = Path(__file__).resolve().parents[3]
        dockerfile_path = repo_root / "src" / "app" / "ecs_service" / "Dockerfile"

        # ====== Container Environment Variables (NO Secrets Manager) ======
        # These values MUST exist in the environment where you run `cdk deploy`
        # (e.g., CodeBuild environment variables).
        env_vars = {
            k: v
            for k, v in {
                # Auth (used by src/common/authorization.py)
                "COGNITO_ISSUER": os.getenv("COGNITO_ISSUER", ""),
                "COGNITO_AUDIENCE": os.getenv("COGNITO_AUDIENCE", ""),

                # Database (if you use Postgres)
                "DB_HOST": os.getenv("DB_HOST", ""),
                "DB_PORT": os.getenv("DB_PORT", ""),
                "DB_NAME": os.getenv("DB_NAME", ""),
                "DB_USER": os.getenv("DB_USER", ""),
                "DB_PASSWORD": os.getenv("DB_PASSWORD", ""),

                # Optional app envs
                "STAGE": os.getenv("STAGE", "dev"),
                "AWS_REGION": os.getenv("AWS_REGION", ""),
            }.items()
            if v not in (None, "")
        }

        container = task_def.add_container(
            "AppContainer",
            image=ecs.ContainerImage.from_asset(
                directory=str(repo_root),  # ✅ build context = root
                file=str(dockerfile_path.relative_to(repo_root)),  # ✅ Dockerfile path relative
                exclude=[
                    "**/cdk.out/**",
                    "**/.git/**",
                    "**/node_modules/**",
                    "**/__pycache__/**",
                    "**/vendor/**",
                    "**/.venv/**",
                    "**/venv/**",
                    "**/dist/**",
                    "**/build/**",
                ],
            ),
            logging=ecs.LogDrivers.aws_logs(
                stream_prefix="ecs",
                log_retention=logs.RetentionDays.ONE_WEEK,
            ),
            environment=env_vars,  # ✅ pass env vars to ECS container
        )

        container.add_port_mappings(
            ecs.PortMapping(container_port=8080, protocol=ecs.Protocol.TCP)
        )

        # ====== Fargate Service + ALB (simple pattern) ======
        ecs_patterns.ApplicationLoadBalancedFargateService(
            self,
            "Service",
            cluster=cluster,
            task_definition=task_def,
            desired_count=1,
            public_load_balancer=True,
            health_check_grace_period=Duration.seconds(60),
            task_subnets=subnet_selection,
        )
