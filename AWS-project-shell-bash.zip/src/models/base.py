from sqlalchemy.ext.declarative import declarative_base

# Defining a base class
Base = declarative_base()
metadata = Base.metadata